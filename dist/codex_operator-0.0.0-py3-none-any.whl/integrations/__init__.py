"""Inicialização do módulo de integrações."""
